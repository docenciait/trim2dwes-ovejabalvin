from django.shortcuts import render, redirect  
from django.contrib.auth.forms import UserCreationForm  
from django.contrib.auth import login, authenticate, logout  
from django.contrib import messages  
from denuncias.models import Denuncia  
from usuarios.forms import CustomUserCreationForm
from django.contrib.auth.models import User  
from django.contrib.auth.decorators import login_required 
def register(request):
    if request.method == 'POST':  
        form = CustomUserCreationForm(request.POST)  
        if form.is_valid():  
            user = form.save()  
            login(request, user)  
            messages.success(request, 'Registro exitoso.')  
            return redirect('profile')  
        else:
            messages.error(request, 'Error en el registro.Prueba de nuevo')  
    else:
        form = CustomUserCreationForm()  
    
    return render(request, 'usuarios/templates/registro.html', {'form': form})  #


def login_view(request):
    if request.method == 'POST':  
        username = request.POST['username']  
        password = request.POST['password']  
        user = authenticate(request, username=username, password=password)  

        if user is not None:  
            login(request, user)  
            messages.success(request, 'Has ingresado exitosamente')  
            next_url = request.GET.get('next', 'profile')  
            return redirect(next_url)  
        else:
            messages.error(request, 'Usuario o contraseña incorrecta.') 
    
    return render(request, 'usuarios/templates/login.html')  #


@login_required  
def profile(request):
    return render(request, 'usuarios/templates/lista_denuncias.html')  #


@login_required  
def logout_view(request):
    logout(request)  
    messages.success(request, 'Has cerrado sesion exitosamente')  
    return redirect('login')  
