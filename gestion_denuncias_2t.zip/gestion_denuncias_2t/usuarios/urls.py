from django.contrib import admin
from django.urls import path , include 
from django.shortcuts import render
from . import views
#Se que el error está aqui pero no lo consigo arreglar
urlpatterns = [
    path('templates/registro.html', views.register, name='registro'), 
    path('templates/login.html', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
]

