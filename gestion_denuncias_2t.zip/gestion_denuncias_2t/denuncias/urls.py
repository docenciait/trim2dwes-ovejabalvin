from django.urls import path  
from . import views  


urlpatterns = [
    path('create/', views.create_denuncia, name='crear_denuncia'),
    path('list/', views.list_denuncia, name='lista_denuncias'),  
    path('update/<int:denuncia_id>/', views.update_denuncia, name='editar_denuncia'),  
    path('delete/<int:denuncia_id>/', views.delete_denuncia, name='eliminar_denuncia'),  
]