from django.shortcuts import render, redirect, get_object_or_404  
from django.contrib import messages  
from .models import Denuncia
from denuncias.forms import DenunciaForm    
from django.contrib.auth.decorators import login_required  

# Vista para crear una nueva denuncia
@login_required  
def create_denuncia(request):
    if request.method == 'POST': 
        form = DenunciaForm(request.POST)
        if form.is_valid(): 
            denuncia = form.save(commit=False)  
            denuncia.user = request.user  
            denuncia.save()  
            messages.success(request, 'Denuncia creada correctamente')  
            return redirect('usuarios/templates/lista_denuncias.html')  
        else:
            messages.error(request, 'Ha habido un error al crear la denuncia, prueba otra vez.')  
    else:
        form = DenunciaForm()  
    return render(request, 'usuarios/templates/crear_denuncia.html', {'form': form})  


@login_required  
def list_denuncia(request):
    denuncia = Denuncia.objects.all()  
    return render(request, 'usuarios/templates/lista_denuncias.html', {'denuncia': denuncia})  


@login_required  
def update_denuncia(request, denuncia_id):
    denuncia = get_object_or_404(denuncia, id=denuncia_id)  
    if request.method == 'POST':  
        form = DenunciaForm(request.POST, instance=denuncia)  
        if form.is_valid(): 
            form.save()  
            messages.success(request, 'Denuncia actualizada correctamente') 
            return redirect('lista_denuncias') 
        else:
            messages.error(request, 'Ha ocurrido un error al actualizar tu denuncia, prueba otra vez')  
    else:
        form = DenunciaForm(instance=denuncia)  
    return render(request, 'usuarios/templates/editar_denuncia.html', {'form': form})  


@login_required  
def delete_denuncia(request, denuncia_id):
    denuncia = get_object_or_404(Denuncia, id=denuncia_id)  
    if request.method == 'POST':  
        denuncia.delete() 
        messages.success(request, 'Denuncia eliminada correctamente')  
        return redirect('lista_denuncias')
    return render(request, 'usuarios/templates/eliminar_denuncia.html', {'denuncia': denuncia})  
    
